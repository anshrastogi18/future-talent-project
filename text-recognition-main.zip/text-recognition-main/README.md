# GET TEXT
## It Is A Simple Program To Extract Text From Image. Text Can Be Hand Written Or Typed. 
Get Text is a simple cloud-enabled and mobile-ready program built using azure cognitive services i.e. Computer vision and Speech service.

- Computer Visison is used for extracting text from images.
- Speech service is used to conver extracted text to speech.



## Features


- Simple and clean UI.
- It is hosted on azure virtul machine.
- Backend Framework : Django.
- For front end it uses HTML, CSS and JavaScript.
- Easy to use and extract text from image.
- User can convert extacted text to speech with one click.

Django App is deployed on azure virtual machine, ip [52.142.60.253](http://52.142.60.253:8000/) and url http://get-text.eastus.cloudapp.azure.com:8000/ 
